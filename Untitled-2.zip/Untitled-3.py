num=int(input("informer o numero."))

media=(num1+num2)/2

print("media")