num=int(input("informer o numero.") )

antecessor =num -1
sucessor = num + 1

print ("O antecessor de {} e {} ". format(num,antecessor))
print ("O antecessor de {} e {} ". format(num,sucessor) )

