nota1=float(input("Informer o numero.") )
nota2=float(input("Informer o numero.") )
nota3=float(input("informer o numero.") )
media =(nota1 + nota2 + nota3)/3